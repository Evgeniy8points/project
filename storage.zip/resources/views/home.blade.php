@extends('layouts.app')

@section('content')
<style>
            

            .m-b-md {
                margin-bottom: 30px;
            }
            h3{
                font-size: 30px;
            }
            .description{
                font-size: 20px;
            }
            .content-user{
                text-align: left;
                padding: 20px;
                left: 20px;
                width: 400px;
                border: solid 1px black;
            }
            label, input{
                width: 100%;
            }
            label{
                background-color: #bea1a1;
                width: 100%;
                margin-bottom: 0px;
                margin-top: 20px;
            }
            .btn{
                background-color: aqua;
                margin-top: 20px;
            }
            .btn:hover{
                background-color: #fff;
                border: solid 1px #000;
            }
        </style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Платеж</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                <div class="content-user">
                <div class="title m-b-md">
                   <div class="row-p">
                   <h3>Your name:</h5>
                   <p class="description">{{Auth::user()->name}}</p>
                   <h3>Your walet:</h5>
                   <p class="description">{{Auth::user()->money}}</p>
                   </div>
                </div>
                @if(Auth::user()->role_id ===1)
                <form action="/transaction"class="form">
                <label for="name">Перевести деньги от:</label>
                <input type="test" name="from_name" placeholder="Your name">
                <label for="name">Перевести пользователю:</label>
                <input type="test" name="name" placeholder="User name">
                <label for="money">Сумма:</label>
                <input type="text" name="money">
                <button class="btn">Submit</button>
                </form>
                @else
                <h3>Hello small people</h3>
                @endif
                </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">Switch Role</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                
                @if(Auth::user()->role_id ===1)
                <form action="/roleswitch"class="form">
                <label for="name">Сменить роль для:</label>
                <input type="test" name="name" placeholder="User name">
                <label for="id">ID роли:</label>
                <input type="test" name="id" placeholder="Id role">
                <button class="btn">Submit</button>
                </form>
                @else
                <h3>Hello small people</h3>
                @endif
                </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">Load Image</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                <form action="{{ route('image.upload')}}" method="post" enctype="multipart/form-data" class="form">
                    @csrf
                <label for="name">Выберете изображение:</label>
                <input type="file" name="file_image">
                <button class="btn" type="Submit">Submit</button>
                </form>
                @isset($path)
                <img src="{{ asset('/storage/'.$path)}}" alt="">
                </div>
                </div>
                @endisset
            </div>
        </div>
    </div>
</div>
@endsection
