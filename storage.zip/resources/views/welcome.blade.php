<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: fixed;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            h3{
                font-size: 30px;
            }
            .description{
                font-size: 20px;
            }
            .content-user{
                text-align: left;
                position: absolute;
                padding: 20px;
                margin-top: -1000px;
                left: 20px;
                width: 400px;
                height: 400px;
                border: solid 1px black;
            }
            .by{
            width: 30%;
            margin:0% 35%;
            height: 500px;
            text-align: center;
            background:#000;
            border-radius: 25px;
            }
            .services{
                border-radius:25px 25px 0 0;
            }
            .serv_description{
                width: 100%;
                height: 300px;
                margin-top: 0;
                border-radius: inherit;
                background: #55c6f1;
            }
            .serv_description h2{
                margin-top: 0px;
                padding-top: 40%;

            }
            .by_serv{
                width: 50%;
                height: 50px;
                font-size: 20px;
                border-radius: 40px;
                margin: 0 25%;
                background: #fff;
                border: solid 1px #55c6f1;
                margin-top: 20%;
            }
            .by_serv:hover{
                background-color: #000;
                border:solid 1px #f1558f;
                color: #fff;
                border-radius: 0px;
                transition: 0.5s;
            }
            .by_serv a{
                text-decoration: none;
                color: inherit;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @if(Auth::user()->role_id === 1)
                        <a href="{{ url('/admin') }}">Admin</a>
                    @endif
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">
                    Laravel
                </div>

                <div class="links">
                    <a href="https://laravel.com/docs">Docs</a>
                    <a href="https://laracasts.com">Laracasts</a>
                    <a href="https://laravel-news.com">News</a>
                    <a href="https://blog.laravel.com">Blog</a>
                    <a href="https://nova.laravel.com">Nova</a>
                    <a href="https://forge.laravel.com">Forge</a>
                    <a href="https://vapor.laravel.com">Vapor</a>
                    <a href="https://github.com/laravel/laravel">GitHub</a>
                </div>
            </div>
        </div>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
                    @if(Auth::user()->role_id === 1)
                        <a href="{{ url('/admin') }}">Admin</a>
                    @endif
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

        <div class="by">
            <div class="services">
                <div class="serv_description">
                    <h2>Таргетинг</h2>
                    <input type="text" name="name111" value="222" >
                </div>
                <a href="byservices"><button class="by_serv" name="price_s" type="submit">2040</button></a>
        </div>
            
        </div>
    </body>
</html>
