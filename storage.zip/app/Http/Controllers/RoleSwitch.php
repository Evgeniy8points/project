<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class RoleSwitch extends Controller
{
    public function role_switch(Request $request){
    	$name = $request->input('name');
    	$user_id = DB::table('users')->where('name', $name)->value('role_id');
    	$role_id = $request->input('id');
    	$user_role = DB::table('user_roles')->where('user_id', $user_id)->value('role_id');
    	$new_role = DB::update("update user_roles set role_id = '$role_id' where user_id = ?", [$user_id]);
    	$new_role_user = DB::update("update users set role_id = '$role_id' where id = ?", [$user_id]);
        dump($user_role);
        die();
        return view('roleswitch');
    }
}
