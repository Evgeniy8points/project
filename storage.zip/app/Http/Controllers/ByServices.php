<?php

namespace App\Http\Controllers;
use DB;
use Auth;
use Illuminate\Http\Request;

class ByServices extends Controller
{
    public function by_services(Request $request)
    {
    	$name_s = $request->input('name111');
		$from_user = Auth::user()->id;
		dump($name_s);
    	return view('welcome');
    }
}
