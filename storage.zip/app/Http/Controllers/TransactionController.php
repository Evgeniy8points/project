<?php

namespace App\Http\Controllers;

use DB;
use Auth;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    public function transaction_money(Request $request)
    {
		$from_name = $request->input('from_name');
		$from_user = Auth::user()->id;
		$for_name = $request->input('name');	
		$for_user = DB::table('users')->where('name', $for_name)->value('id');
		$money = $request->input('money');	
		$last_money = DB::table('users')->where('id', $for_user)->value('money');
		$new_money= $last_money + $money;


		$update_money = DB::update("update users set money = '$new_money' where id = ?",[$for_user]);
    	$transaction_money = DB::insert('insert into transactions (from_id, id, from_name, name, money) values (?, ?, ?, ?, ?)', 
    		[$from_user, $for_user, $from_name, $for_name, $money]);

    	dump($new_money);		
    	die();
    	
    }
}
