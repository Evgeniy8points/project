<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use Intervention\Image\ImageManager;
use Intervention\Image\Facades\Image as ImageInt;
class LoadImage extends Controller
{
    //public function load_image(Request $request)
    //{
    //$manager = new ImageManager(array('driver' => 'imagick'));
    //$path = $request->file('file_image')->store('uploads', 'public');
    //$image = $manager->make('public/foo.jpg')->resize(300, 200);
    //return view('home', ['path'=>$path]);
	//}

	public function index()
    {
        $images = Image::all();
        return view('images.index',['images' => $images]);
    }


    public function create()
	{
    return view('images.create');
	}


	public function store(Request $request)
	{
    $path =public_path().'\upload\\';
    $file = $request->file('file');

    foreach ($file as $f) {
        $filename = str_random(20) .'.' . $f->getClientOriginalExtension() ?: 'png';
        $img = ImageInt::make($f);
        $img->resize(200,200)->save($path . $filename);
        Image::create(['title' => $request->title, 'img' => $filename]);
    }

    return redirect()->route('images.index');
}




}
